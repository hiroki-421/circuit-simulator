import type { Circuit, CircuitComponent, Pin, Point, Wire } from "./types.js";

/**
 * Circuit に対する読み書き操作をまとめたヘルパー。
 * イミュータブルに扱う(常に新しい Circuit を返す)ことで、
 * Reactの状態管理(Zustand等)や undo/redo と相性を良くしている。
 */
export class CircuitGraph {
  constructor(private circuit: Circuit) {}

  static from(circuit: Circuit): CircuitGraph {
    return new CircuitGraph(circuit);
  }

  get value(): Circuit {
    return this.circuit;
  }

  addComponent(component: CircuitComponent): CircuitGraph {
    return new CircuitGraph({
      ...this.circuit,
      components: [...this.circuit.components, component],
    });
  }

  removeComponent(componentId: string): CircuitGraph {
    const pinIds = new Set(
      this.circuit.components
        .find((c) => c.id === componentId)
        ?.pins.map((p) => p.id) ?? [],
    );
    return new CircuitGraph({
      ...this.circuit,
      components: this.circuit.components.filter((c) => c.id !== componentId),
      // そのコンポーネントに繋がっていた配線も一緒に削除する
      wires: this.circuit.wires.filter(
        (w) => !pinIds.has(w.pinAId) && !pinIds.has(w.pinBId),
      ),
    });
  }

  moveComponent(componentId: string, position: Point): CircuitGraph {
    return new CircuitGraph({
      ...this.circuit,
      components: this.circuit.components.map((c) =>
        c.id === componentId ? { ...c, position } : c,
      ),
    });
  }

  addWire(pinAId: string, pinBId: string): CircuitGraph {
    if (pinAId === pinBId) return this;
    const wire: Wire = { id: crypto.randomUUID(), pinAId, pinBId };
    return new CircuitGraph({
      ...this.circuit,
      wires: [...this.circuit.wires, wire],
    });
  }

  removeWire(wireId: string): CircuitGraph {
    return new CircuitGraph({
      ...this.circuit,
      wires: this.circuit.wires.filter((w) => w.id !== wireId),
    });
  }

  findPin(pinId: string): Pin | undefined {
    for (const c of this.circuit.components) {
      const pin = c.pins.find((p) => p.id === pinId);
      if (pin) return pin;
    }
    return undefined;
  }

  findComponentOfPin(pinId: string): CircuitComponent | undefined {
    return this.circuit.components.find((c) =>
      c.pins.some((p) => p.id === pinId),
    );
  }

  /**
   * 「ネット」= 配線でつながった、電気的に同一とみなせるピンの集合を
   * すべて求める(Union-Findで連結成分を作る)。
   *
   * デジタルシミュレーションでは「このネットに1つでもHIGH出力があればHIGH」
   * といった評価に使い、将来のアナログ(MNA)実装では「同一節点」として
   * そのまま使える共通の土台になる。
   */
  computeNets(): Pin[][] {
    const parent = new Map<string, string>();
    const find = (id: string): string => {
      if (!parent.has(id)) parent.set(id, id);
      let root = id;
      while (parent.get(root) !== root) root = parent.get(root)!;
      parent.set(id, root);
      return root;
    };
    const union = (a: string, b: string) => {
      const ra = find(a);
      const rb = find(b);
      if (ra !== rb) parent.set(ra, rb);
    };

    const allPins: Pin[] = this.circuit.components.flatMap((c) => c.pins);
    for (const pin of allPins) find(pin.id);
    for (const wire of this.circuit.wires) union(wire.pinAId, wire.pinBId);

    const groups = new Map<string, Pin[]>();
    for (const pin of allPins) {
      const root = find(pin.id);
      if (!groups.has(root)) groups.set(root, []);
      groups.get(root)!.push(pin);
    }
    return [...groups.values()];
  }
}
