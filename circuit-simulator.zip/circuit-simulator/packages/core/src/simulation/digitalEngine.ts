import { CircuitGraph } from "../CircuitGraph.js";
import type { Circuit } from "../types.js";

/**
 * デジタル回路シミュレーションの結果。
 * pinValues: 各ピンidに対する論理値(true=HIGH, false=LOW)
 */
export interface DigitalSimulationResult {
  pinValues: Record<string, boolean>;
}

/**
 * ごく単純な「レベル」シミュレーション。
 *
 * 制約(現時点では意図的に単純化している):
 * - 遅延を持たない(全ゲートが瞬時に反応すると仮定)
 * - 1本のネットに複数の出力ピンが繋がった場合は「どれか1つでもHIGHなら
 *   ネット全体がHIGH」という簡略化したワイヤードOR的挙動として扱う
 *   (実物の回路のようなショート/バス競合の検出はしない)
 * - フィードバックのある回路(ラッチなど)は、値が収束するまで
 *   反復計算することである程度動くが、発振などは正しく再現できない
 *
 * これらはフェーズ2以降、より正確なイベント駆動シミュレーションに
 * 置き換える前提の "動くたたき台" として割り切っている。
 */
export function simulateDigital(circuit: Circuit): DigitalSimulationResult {
  const graph = CircuitGraph.from(circuit);
  const nets = graph.computeNets();

  const state: Record<string, boolean> = {};
  for (const component of circuit.components) {
    for (const pin of component.pins) {
      state[pin.id] = false;
    }
    if (component.type === "INPUT_SWITCH") {
      const outPin = component.pins.find((p) => p.name === "out");
      if (outPin) state[outPin.id] = Boolean(component.properties.value);
    }
  }

  const MAX_ITERATIONS = 20;
  for (let iteration = 0; iteration < MAX_ITERATIONS; iteration++) {
    let changed = false;

    // 1. ネットごとに、出力側ピンの値を入力側ピンへ伝播する
    for (const net of nets) {
      const driverValue = net.some(
        (pin) => pin.kind === "output" && state[pin.id],
      );
      for (const pin of net) {
        if (pin.kind !== "output" && state[pin.id] !== driverValue) {
          state[pin.id] = driverValue;
          changed = true;
        }
      }
    }

    // 2. 各ゲートの出力を、現在の入力値から再計算する
    for (const component of circuit.components) {
      const pinByName = (name: string) =>
        component.pins.find((p) => p.name === name);
      let nextOutput: boolean | undefined;

      switch (component.type) {
        case "AND_GATE": {
          const in1 = pinByName("in1");
          const in2 = pinByName("in2");
          if (in1 && in2) nextOutput = state[in1.id] && state[in2.id];
          break;
        }
        case "OR_GATE": {
          const in1 = pinByName("in1");
          const in2 = pinByName("in2");
          if (in1 && in2) nextOutput = state[in1.id] || state[in2.id];
          break;
        }
        case "NOT_GATE": {
          const in1 = pinByName("in1");
          if (in1) nextOutput = !state[in1.id];
          break;
        }
        default:
          break;
      }

      if (nextOutput !== undefined) {
        const outPin = pinByName("out");
        if (outPin && state[outPin.id] !== nextOutput) {
          state[outPin.id] = nextOutput;
          changed = true;
        }
      }
    }

    if (!changed) break;
  }

  return { pinValues: state };
}

/** LEDが点灯しているかどうかを判定するヘルパー。 */
export function isLedLit(
  circuit: Circuit,
  ledComponentId: string,
  result: DigitalSimulationResult,
): boolean {
  const led = circuit.components.find((c) => c.id === ledComponentId);
  const anode = led?.pins.find((p) => p.name === "anode");
  return anode ? result.pinValues[anode.id] === true : false;
}
