import type {
  ComponentProperties,
  ComponentType,
  Pin,
  Point,
} from "./types.js";

/**
 * 「コンポーネントの種類」ごとの静的な定義。
 * エディタのパレット表示や、新規コンポーネント生成時のひな形として使う。
 */
export interface ComponentDefinition {
  type: ComponentType;
  /** パレットや一覧に表示するラベル */
  label: string;
  /** エディタ上での見た目のサイズ(幅・高さ) */
  size: { width: number; height: number };
  /** ピンのひな形(offsetは size を基準にした相対座標) */
  pinTemplates: Array<Pick<Pin, "name" | "kind" | "offset">>;
  defaultProperties: ComponentProperties;
}

const gateSize = { width: 60, height: 40 };

export const COMPONENT_DEFINITIONS: Record<ComponentType, ComponentDefinition> = {
  INPUT_SWITCH: {
    type: "INPUT_SWITCH",
    label: "入力スイッチ",
    size: { width: 40, height: 40 },
    pinTemplates: [
      { name: "out", kind: "output", offset: { x: 40, y: 20 } },
    ],
    defaultProperties: { value: false },
  },
  AND_GATE: {
    type: "AND_GATE",
    label: "ANDゲート",
    size: gateSize,
    pinTemplates: [
      { name: "in1", kind: "input", offset: { x: 0, y: 10 } },
      { name: "in2", kind: "input", offset: { x: 0, y: 30 } },
      { name: "out", kind: "output", offset: { x: 60, y: 20 } },
    ],
    defaultProperties: {},
  },
  OR_GATE: {
    type: "OR_GATE",
    label: "ORゲート",
    size: gateSize,
    pinTemplates: [
      { name: "in1", kind: "input", offset: { x: 0, y: 10 } },
      { name: "in2", kind: "input", offset: { x: 0, y: 30 } },
      { name: "out", kind: "output", offset: { x: 60, y: 20 } },
    ],
    defaultProperties: {},
  },
  NOT_GATE: {
    type: "NOT_GATE",
    label: "NOTゲート",
    size: gateSize,
    pinTemplates: [
      { name: "in1", kind: "input", offset: { x: 0, y: 20 } },
      { name: "out", kind: "output", offset: { x: 60, y: 20 } },
    ],
    defaultProperties: {},
  },
  LED: {
    type: "LED",
    label: "LED",
    size: { width: 30, height: 30 },
    pinTemplates: [
      { name: "anode", kind: "input", offset: { x: 0, y: 15 } },
    ],
    defaultProperties: {},
  },
  // --- アナログ素子。フェーズ2以降のシミュレーション実装で使う ---
  RESISTOR: {
    type: "RESISTOR",
    label: "抵抗",
    size: { width: 60, height: 20 },
    pinTemplates: [
      { name: "t1", kind: "terminal", offset: { x: 0, y: 10 } },
      { name: "t2", kind: "terminal", offset: { x: 60, y: 10 } },
    ],
    defaultProperties: { resistanceOhm: 1000 },
  },
  BATTERY: {
    type: "BATTERY",
    label: "電源",
    size: { width: 40, height: 40 },
    pinTemplates: [
      { name: "plus", kind: "terminal", offset: { x: 40, y: 20 } },
      { name: "minus", kind: "terminal", offset: { x: 0, y: 20 } },
    ],
    defaultProperties: { voltage: 5 },
  },
  CAPACITOR: {
    type: "CAPACITOR",
    label: "コンデンサ",
    size: { width: 40, height: 20 },
    pinTemplates: [
      { name: "t1", kind: "terminal", offset: { x: 0, y: 10 } },
      { name: "t2", kind: "terminal", offset: { x: 40, y: 10 } },
    ],
    defaultProperties: { capacitanceFarad: 0.000001 },
  },
};

/** 新しいコンポーネントインスタンスをidを振って生成する。 */
export function instantiateComponent(
  type: ComponentType,
  position: Point,
) {
  const def = COMPONENT_DEFINITIONS[type];
  const componentId = crypto.randomUUID();
  const pins: Pin[] = def.pinTemplates.map((t) => ({
    id: crypto.randomUUID(),
    componentId,
    name: t.name,
    kind: t.kind,
    offset: t.offset,
  }));
  return {
    id: componentId,
    type,
    position,
    rotation: 0 as const,
    pins,
    properties: { ...def.defaultProperties },
  };
}
