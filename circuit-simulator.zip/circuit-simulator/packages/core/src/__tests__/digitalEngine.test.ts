import { describe, expect, it } from "vitest";
import { CircuitGraph } from "../CircuitGraph.js";
import { instantiateComponent } from "../componentDefs.js";
import { simulateDigital } from "../simulation/digitalEngine.js";
import { createEmptyCircuit } from "../types.js";

function pin(component: ReturnType<typeof instantiateComponent>, name: string) {
  const p = component.pins.find((pin) => pin.name === name);
  if (!p) throw new Error(`pin ${name} not found`);
  return p;
}

describe("simulateDigital", () => {
  it("ANDゲート: 両方HIGHのときだけ出力がHIGHになる", () => {
    const switchA = instantiateComponent("INPUT_SWITCH", { x: 0, y: 0 });
    const switchB = instantiateComponent("INPUT_SWITCH", { x: 0, y: 100 });
    const and = instantiateComponent("AND_GATE", { x: 100, y: 50 });

    switchA.properties.value = true;
    switchB.properties.value = true;

    let graph = CircuitGraph.from(createEmptyCircuit())
      .addComponent(switchA)
      .addComponent(switchB)
      .addComponent(and);

    graph = graph
      .addWire(pin(switchA, "out").id, pin(and, "in1").id)
      .addWire(pin(switchB, "out").id, pin(and, "in2").id);

    const result = simulateDigital(graph.value);
    expect(result.pinValues[pin(and, "out").id]).toBe(true);

    switchB.properties.value = false;
    const result2 = simulateDigital(graph.value);
    expect(result2.pinValues[pin(and, "out").id]).toBe(true); // graph.value snapshot still has original switchB
  });

  it("NOTゲート: 入力を反転する", () => {
    const sw = instantiateComponent("INPUT_SWITCH", { x: 0, y: 0 });
    sw.properties.value = false;
    const not = instantiateComponent("NOT_GATE", { x: 100, y: 0 });

    const graph = CircuitGraph.from(createEmptyCircuit())
      .addComponent(sw)
      .addComponent(not)
      .addWire(pin(sw, "out").id, pin(not, "in1").id);

    const result = simulateDigital(graph.value);
    expect(result.pinValues[pin(not, "out").id]).toBe(true);
  });

  it("LED: 未接続の入力はLOW扱いになる", () => {
    const led = instantiateComponent("LED", { x: 0, y: 0 });
    const graph = CircuitGraph.from(createEmptyCircuit()).addComponent(led);
    const result = simulateDigital(graph.value);
    expect(result.pinValues[pin(led, "anode").id]).toBe(false);
  });
});
