/**
 * 回路シミュレーター/エディタの中核データモデル。
 *
 * 設計方針:
 * - デジタル素子とアナログ素子を「同じ土俵」で表現できるようにする。
 *   将来アナログ(MNA法など)に拡張したときも、Component/Pin/Wireという
 *   グラフ構造自体は変えずに済むようにしておく。
 * - エディタ(見た目・座標)とシミュレーター(電気的な振る舞い)が
 *   同じデータを参照できるように、位置情報と電気的情報を同じ
 *   Component オブジェクトに持たせる。
 */

/** 2次元座標。エディタ上の位置やピンの相対位置に使う。 */
export interface Point {
  x: number;
  y: number;
}

/**
 * ピンの電気的な種類。
 * - "input" / "output": デジタル素子の入出力(信号の向きが決まっている)
 * - "terminal": アナログ素子の端子(電流が双方向に流れうる。抵抗の両端など)
 */
export type PinKind = "input" | "output" | "terminal";

export interface Pin {
  id: string;
  /** このピンを持つコンポーネントのid */
  componentId: string;
  /** "in1", "out", "anode" のような人間に分かる名前 */
  name: string;
  kind: PinKind;
  /** コンポーネント原点からの相対位置(回転前の座標系) */
  offset: Point;
}

/** 現時点でサポートするコンポーネントの種類。今後ここに追加していく。 */
export type ComponentType =
  // --- デジタル素子(フェーズ1) ---
  | "INPUT_SWITCH" // 手動でHIGH/LOWを切り替えられる入力源
  | "AND_GATE"
  | "OR_GATE"
  | "NOT_GATE"
  | "LED"
  // --- アナログ素子(フェーズ2以降で使用。今は型だけ用意) ---
  | "RESISTOR"
  | "BATTERY"
  | "CAPACITOR";

/** コンポーネント固有のパラメータ。種類ごとに使うキーは異なる。 */
export type ComponentProperties = Record<string, number | string | boolean>;

export interface CircuitComponent {
  id: string;
  type: ComponentType;
  /** エディタ上の位置(左上基準ではなく、コンポーネントの基準点) */
  position: Point;
  /** 0 / 90 / 180 / 270 度単位での回転 */
  rotation: 0 | 90 | 180 | 270;
  pins: Pin[];
  properties: ComponentProperties;
}

/** 2つのピンを結ぶ配線。有向グラフにせず、常に無向(pinA-pinB)として扱う。 */
export interface Wire {
  id: string;
  pinAId: string;
  pinBId: string;
}

export interface Circuit {
  id: string;
  name: string;
  components: CircuitComponent[];
  wires: Wire[];
}

/** 空の回路を作るヘルパー。 */
export function createEmptyCircuit(name = "untitled"): Circuit {
  return {
    id: crypto.randomUUID(),
    name,
    components: [],
    wires: [],
  };
}
