import { simulateDigital } from "@circuit-sim/core";
import { useMemo, useRef, useState } from "react";
import { useCircuitStore } from "../state/useCircuitStore";
import { ComponentView } from "./ComponentView";
import { WireView } from "./WireView";

interface DragState {
  componentId: string;
  /** マウス位置からコンポーネント原点までのオフセット */
  grabOffset: { x: number; y: number };
}

export function CircuitEditor() {
  const graph = useCircuitStore((s) => s.graph);
  const pendingWireStartPinId = useCircuitStore((s) => s.pendingWireStartPinId);
  const moveComponent = useCircuitStore((s) => s.moveComponent);
  const cancelPendingWire = useCircuitStore((s) => s.cancelPendingWire);

  const circuit = graph.value;
  // 回路が変化するたびにシミュレーションを再計算する(MVPでは常に全体を再計算)
  const simulation = useMemo(() => simulateDigital(circuit), [circuit]);

  const svgRef = useRef<SVGSVGElement>(null);
  const [drag, setDrag] = useState<DragState | null>(null);

  function toSvgPoint(e: React.MouseEvent) {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  function handleComponentDragStart(componentId: string, e: React.MouseEvent) {
    e.stopPropagation();
    const component = circuit.components.find((c) => c.id === componentId);
    if (!component) return;
    const p = toSvgPoint(e);
    setDrag({
      componentId,
      grabOffset: {
        x: p.x - component.position.x,
        y: p.y - component.position.y,
      },
    });
  }

  function handleMouseMove(e: React.MouseEvent) {
    if (!drag) return;
    const p = toSvgPoint(e);
    moveComponent(drag.componentId, {
      x: p.x - drag.grabOffset.x,
      y: p.y - drag.grabOffset.y,
    });
  }

  return (
    <svg
      ref={svgRef}
      className="editor-canvas"
      onMouseMove={handleMouseMove}
      onMouseUp={() => setDrag(null)}
      onMouseLeave={() => setDrag(null)}
      onClick={() => cancelPendingWire()}
    >
      <defs>
        <pattern id="grid" width={20} height={20} patternUnits="userSpaceOnUse">
          <path d="M 20 0 L 0 0 0 20" className="grid-line" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grid)" />

      {circuit.wires.map((wire) => (
        <WireView key={wire.id} wire={wire} circuit={circuit} simulation={simulation} />
      ))}

      {circuit.components.map((component) => (
        <ComponentView
          key={component.id}
          component={component}
          simulation={simulation}
          pendingWireStartPinId={pendingWireStartPinId}
          onDragStart={handleComponentDragStart}
        />
      ))}
    </svg>
  );
}
