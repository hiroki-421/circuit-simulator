import { Circuit, DigitalSimulationResult, Wire } from "@circuit-sim/core";
import { getPinAbsolutePosition } from "../utils";

interface Props {
  wire: Wire;
  circuit: Circuit;
  simulation: DigitalSimulationResult;
}

export function WireView({ wire, circuit, simulation }: Props) {
  const a = getPinAbsolutePosition(circuit, wire.pinAId);
  const b = getPinAbsolutePosition(circuit, wire.pinBId);
  if (!a || !b) return null;

  const isHigh =
    simulation.pinValues[wire.pinAId] || simulation.pinValues[wire.pinBId];

  return (
    <line
      x1={a.x}
      y1={a.y}
      x2={b.x}
      y2={b.y}
      className={isHigh ? "wire wire-high" : "wire"}
    />
  );
}
