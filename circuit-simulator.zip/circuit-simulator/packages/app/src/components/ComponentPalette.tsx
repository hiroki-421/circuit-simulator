import { ComponentType } from "@circuit-sim/core";
import { useCircuitStore } from "../state/useCircuitStore";

const PALETTE_ITEMS: { type: ComponentType; label: string }[] = [
  { type: "INPUT_SWITCH", label: "入力スイッチ" },
  { type: "AND_GATE", label: "AND" },
  { type: "OR_GATE", label: "OR" },
  { type: "NOT_GATE", label: "NOT" },
  { type: "LED", label: "LED" },
];

let placementCounter = 0;

export function ComponentPalette() {
  const addComponent = useCircuitStore((s) => s.addComponent);

  return (
    <div className="palette">
      <h2>部品</h2>
      {PALETTE_ITEMS.map((item) => (
        <button
          key={item.type}
          className="palette-button"
          onClick={() => {
            placementCounter += 1;
            addComponent(item.type, {
              x: 80 + (placementCounter % 5) * 90,
              y: 60 + Math.floor(placementCounter / 5) * 90,
            });
          }}
        >
          {item.label}
        </button>
      ))}
      <p className="palette-hint">
        部品をクリックで配置 / ピンをクリックして配線 / 部品をダブルクリックで削除
        / スイッチはクリックでON・OFF切り替え
      </p>
    </div>
  );
}
