import { CircuitComponent, DigitalSimulationResult } from "@circuit-sim/core";
import { useCircuitStore } from "../state/useCircuitStore";

interface Props {
  component: CircuitComponent;
  simulation: DigitalSimulationResult;
  pendingWireStartPinId: string | null;
  onDragStart: (componentId: string, e: React.MouseEvent) => void;
}

/** コンポーネント種類ごとの見た目(本体の形)を描くヘルパー */
function ComponentBody({ component }: { component: CircuitComponent }) {
  switch (component.type) {
    case "INPUT_SWITCH": {
      const on = Boolean(component.properties.value);
      return (
        <g>
          <rect
            width={40}
            height={40}
            rx={6}
            className={on ? "body body-switch-on" : "body body-switch"}
          />
          <text x={20} y={24} textAnchor="middle" className="label">
            {on ? "1" : "0"}
          </text>
        </g>
      );
    }
    case "AND_GATE":
      return (
        <g>
          <path
            d="M0,0 H30 A20,20 0 0 1 30,40 H0 Z"
            className="body body-gate"
          />
          <text x={18} y={24} textAnchor="middle" className="label">
            AND
          </text>
        </g>
      );
    case "OR_GATE":
      return (
        <g>
          <path
            d="M0,0 Q20,20 0,40 Q40,35 60,20 Q40,5 0,0 Z"
            className="body body-gate"
          />
          <text x={22} y={24} textAnchor="middle" className="label">
            OR
          </text>
        </g>
      );
    case "NOT_GATE":
      return (
        <g>
          <path d="M0,0 L45,20 L0,40 Z" className="body body-gate" />
          <circle cx={52} cy={20} r={7} className="body body-gate" />
          <text x={18} y={24} textAnchor="middle" className="label">
            NOT
          </text>
        </g>
      );
    case "LED":
      return <circle cx={15} cy={15} r={15} className="body body-led" />;
    default:
      return <rect width={40} height={40} className="body" />;
  }
}

export function ComponentView({
  component,
  simulation,
  pendingWireStartPinId,
  onDragStart,
}: Props) {
  const toggleSwitch = useCircuitStore((s) => s.toggleSwitch);
  const handlePinClick = useCircuitStore((s) => s.handlePinClick);
  const removeComponent = useCircuitStore((s) => s.removeComponent);

  const isLit =
    component.type === "LED" &&
    simulation.pinValues[component.pins[0]?.id ?? ""] === true;

  return (
    <g
      transform={`translate(${component.position.x}, ${component.position.y})`}
      onMouseDown={(e) => onDragStart(component.id, e)}
      onDoubleClick={() => removeComponent(component.id)}
      onClick={() => {
        if (component.type === "INPUT_SWITCH") toggleSwitch(component.id);
      }}
      className={component.type === "LED" && isLit ? "lit" : undefined}
    >
      <ComponentBody component={component} />
      {component.pins.map((pin) => {
        const isPending = pendingWireStartPinId === pin.id;
        const value = simulation.pinValues[pin.id];
        return (
          <circle
            key={pin.id}
            cx={pin.offset.x}
            cy={pin.offset.y}
            r={5}
            className={
              "pin " +
              (isPending ? "pin-pending" : value ? "pin-high" : "pin-low")
            }
            onClick={(e) => {
              e.stopPropagation();
              handlePinClick(pin.id);
            }}
          />
        );
      })}
    </g>
  );
}
