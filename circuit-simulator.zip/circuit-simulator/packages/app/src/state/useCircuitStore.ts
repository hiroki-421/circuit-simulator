import {
  CircuitGraph,
  ComponentType,
  createEmptyCircuit,
  instantiateComponent,
  Point,
} from "@circuit-sim/core";
import { create } from "zustand";

interface CircuitStore {
  graph: CircuitGraph;
  /** 配線を描いている途中の起点ピン(未確定) */
  pendingWireStartPinId: string | null;

  addComponent: (type: ComponentType, position: Point) => void;
  moveComponent: (componentId: string, position: Point) => void;
  removeComponent: (componentId: string) => void;
  toggleSwitch: (componentId: string) => void;
  handlePinClick: (pinId: string) => void;
  cancelPendingWire: () => void;
}

export const useCircuitStore = create<CircuitStore>((set, get) => ({
  graph: CircuitGraph.from(createEmptyCircuit("my-circuit")),
  pendingWireStartPinId: null,

  addComponent: (type, position) =>
    set((s) => ({
      graph: s.graph.addComponent(instantiateComponent(type, position)),
    })),

  moveComponent: (componentId, position) =>
    set((s) => ({ graph: s.graph.moveComponent(componentId, position) })),

  removeComponent: (componentId) =>
    set((s) => ({ graph: s.graph.removeComponent(componentId) })),

  toggleSwitch: (componentId) =>
    set((s) => {
      const component = s.graph.value.components.find(
        (c) => c.id === componentId,
      );
      if (!component || component.type !== "INPUT_SWITCH") return s;
      const updated = {
        ...component,
        properties: { ...component.properties, value: !component.properties.value },
      };
      const nextComponents = s.graph.value.components.map((c) =>
        c.id === componentId ? updated : c,
      );
      return {
        graph: CircuitGraph.from({ ...s.graph.value, components: nextComponents }),
      };
    }),

  handlePinClick: (pinId) =>
    set((s) => {
      if (!s.pendingWireStartPinId) {
        return { pendingWireStartPinId: pinId };
      }
      if (s.pendingWireStartPinId === pinId) {
        return { pendingWireStartPinId: null };
      }
      return {
        graph: s.graph.addWire(s.pendingWireStartPinId, pinId),
        pendingWireStartPinId: null,
      };
    }),

  cancelPendingWire: () => set({ pendingWireStartPinId: null }),
}));
