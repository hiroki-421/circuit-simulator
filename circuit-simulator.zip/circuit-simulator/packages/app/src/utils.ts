import { Circuit, Point } from "@circuit-sim/core";

/** ピンidから、エディタ上の絶対座標(コンポーネント位置+ピンの相対座標)を求める。 */
export function getPinAbsolutePosition(
  circuit: Circuit,
  pinId: string,
): Point | null {
  for (const component of circuit.components) {
    const pin = component.pins.find((p) => p.id === pinId);
    if (pin) {
      return {
        x: component.position.x + pin.offset.x,
        y: component.position.y + pin.offset.y,
      };
    }
  }
  return null;
}
