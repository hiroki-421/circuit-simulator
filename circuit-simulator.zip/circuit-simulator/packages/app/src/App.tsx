import { CircuitEditor } from "./components/CircuitEditor";
import { ComponentPalette } from "./components/ComponentPalette";

export function App() {
  return (
    <div className="app-layout">
      <header className="app-header">
        <h1>回路シミュレーター</h1>
        <span className="app-header-sub">Phase 1: デジタル回路</span>
      </header>
      <div className="app-body">
        <ComponentPalette />
        <CircuitEditor />
      </div>
    </div>
  );
}
